//
//  File.swift
//  maze
//
//  Created by Erdan Li on 16/4/27.
//  Copyright © 2016年 Kuntao Zhu. All rights reserved.
//


import SpriteKit
import CoreMotion

class GameScene2: SKScene, SKPhysicsContactDelegate {
    let manager = CMMotionManager()
    var player = SKSpriteNode()
    var endnode = SKSpriteNode()
    
    override func didMoveToView(view: SKView) {
        
        self.physicsWorld.contactDelegate = self
        
        player = self.childNodeWithName("player") as! SKSpriteNode
        
        endnode = self.childNodeWithName("endnode") as! SKSpriteNode
        
        manager.startAccelerometerUpdates()
        manager.accelerometerUpdateInterval = 0.1
        manager.startAccelerometerUpdatesToQueue(NSOperationQueue.mainQueue()){
            (data, error) in
            
            self.physicsWorld.gravity = CGVectorMake(CGFloat((data?.acceleration.x)!) * 15, CGFloat((data?.acceleration.y)!) * 15)
        }
        
        
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        var bodya = contact.bodyA
        var bodyb = contact.bodyB
        
        if bodya.categoryBitMask == 1 && bodyb.categoryBitMask == 2 || bodya.categoryBitMask == 2 && bodyb.categoryBitMask == 1 {
            print("you win")
            
        }
    }
    
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}
