//
//  Scen2.swift
//  maze
//
//  Created by Erdan Li on 16/4/27.
//  Copyright © 2016年 Kuntao Zhu. All rights reserved.
//

import Foundation
